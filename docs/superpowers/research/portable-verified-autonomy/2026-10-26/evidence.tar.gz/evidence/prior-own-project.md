<!-- scope:agent-practices-evidence -->
# Own-project evidence: getff and its operator contour

> **Authoritative for:** this research session's bounded source observations and local probe receipts at the revision below.
> **NOT authoritative for:** adopted policy, current live runtime permissions, deployed consumer behavior, or whole-project quality.

Research date: 2026-10-26. Inputs-ref: `943e417c5a70d4589d5ee75fcf6ee273a9d46bfd`.
Commit timestamp: `2026-10-26T07:00:43+03:00`. The checkout started clean and detached; its `origin/staging` tracking ref named the same commit. No remote freshness claim is inferred from that tracking ref. Sources below were read from this unchanged tree.

## Evidence vocabulary

- **SOURCE:** implementation or explicit documentation inspected; behavior was not exercised.
- **PROBE:** a named local command ran in this session; its scope is recorded.
- **POLICY:** a stated rule, without an assertion that every session obeys it.
- **UNKNOWN:** access, deployment or outcome evidence was not collected.

## Verified mechanisms and their boundaries

| ID | Observation | Evidence | Boundary |
|---|---|---|---|
| O01 | The project's primary product is convention enforcement; its operator orchestration is a distinct contour. | `README.md`, sections "Why this exists", "What this project is and isn't", "What's in the repo (operator contour)". [Pinned source](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/README.md) | A personal assistant UI, connector catalogue or managed VM is not automatically missing product scope. |
| O02 | Bootstrap points to repository knowledge and authority owners; it does not require recovering a chat transcript to know the goal. | `.agents/session-bootstrap.md:25`, `.agents/session-bootstrap.md:35`; [source](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/.agents/session-bootstrap.md#L25-L46) | Loading instructions is not proof they are followed. |
| O03 | Durable behavioral conventions must be codified in the repository, then memory becomes a pointer carrying the codifying SHA. | `.agents/rules/memory-codification.md:37`; [source](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/.agents/rules/memory-codification.md#L37-L43) | This is policy. The associated hook is a reminder, not a transaction ensuring both writes happened. |
| O04 | That hook reacts to `Write` and `/memory/` paths, emits additional context, and caches one firing per session. | `.agents/hooks/inject-memory-codification.sh:29`; [source](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/.agents/hooks/inject-memory-codification.sh#L29-L59) | It does not validate source truth, enforce TTL, cover every memory API, or prove Codex host activation. |
| O05 | A separate reporting agent enumerates memory entries, distinguishes conventions from legitimate memory, and checks repository codification. | `.agents/roles/memory-codification-auditor.md:42`; [source](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/.agents/roles/memory-codification-auditor.md#L42-L75) | Private memory was not read or audited in this session. |
| O06 | Cold review continuity is carried by a compact watch-list; follow-ups default to a fresh narrow seat, with a documented resume exception. | `.agents/rules/cold-seat-economy.md:67`; [source](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/.agents/rules/cold-seat-economy.md#L67-L106) | Its small observational cost table is not a controlled benchmark. Nominal tokens are not billed cost, especially across cache/model changes. |
| O07 | Review inputs can be immutable per-file snapshots, and dispatch templates require `Inputs-ref`. | `.agents/rules/cold-seat-economy.md:172`, `scripts/snapshot-for-seat.sh`, `packages/core/principles/50-cold-seat-inputs-ref.test.ts`; [rule](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/.agents/rules/cold-seat-economy.md#L172) | A required field is not proof the seat read the snapshot, or that its judgment is correct. |
| O08 | Dispatcher guidance distinguishes lifecycle DONE, pending result obligations, independent review, and actual delivery acceptance. Rework state belongs in durable task comments, PRs and git. | `.agents/procedures/dispatcher/references/execution.md:140`, `:218`; [source](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/.agents/procedures/dispatcher/references/execution.md#L140-L149) | The full external aif coordinator and its deployed database were not exercised. |
| O09 | Bridge claim/release splits creation from execution. Tasks are created paused, with review enabled; declared intent scopes disable automatic implementation. | `packages/runtime-bridge/src/AifHandoffBackend.ts:296`, `:376`; [source](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/packages/runtime-bridge/src/AifHandoffBackend.ts#L296-L388) | The isolation self-heal at lines 325–343 is explicitly best effort: failure warns and continues. A worktree also does not provide an OS privilege boundary. |
| O10 | Scoped starts require a PlanReview bound to the task, contract, effective-plan digest, task pre-image and owner reference; the CLI rereads before posting the start event. | `packages/runtime-bridge/src/resultReview.ts:53`, `packages/runtime-bridge/src/cli/start-reviewed.ts:76`; [start code](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/packages/runtime-bridge/src/cli/start-reviewed.ts#L76-L117) | This is a scoped product-plan gate, not general authorization for all shell/MCP actions. The code does two reads and a POST; it does not demonstrate an atomic server-side compare-and-start transaction. |
| O11 | Invalid declared scope fails closed before dispatch deduplication; `--force` does not bypass that validation. | `packages/runtime-bridge/src/cli/dispatch.ts:183`; [source](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/packages/runtime-bridge/src/cli/dispatch.ts#L183-L214) | These source paths were inspected, not live-dispatched. |
| O12 | Content-hash dispatch deduplication has a 24-hour TTL and prune-on-write cleanup. | `packages/runtime-bridge/src/idempotency.ts:65`, `:80`, `:106`; [source](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/packages/runtime-bridge/src/idempotency.ts#L60-L117) | This TTL belongs to dispatch bookkeeping, not memory validity. JSONL rewrite/check is not proof of cross-process atomicity or exactly-once external effects. |
| O13 | Convention machinery includes executable checks, negative-example requirements, firing contracts and generated-rule integrity verification. | `packages/core/principles/01-executable-check.test.ts:55`, `02-paired-negative-test.test.ts:8`, `packages/core/backends/npm/firing-contract.json:1`, `packages/core/synthesizer/verify-provenance.ts:1` | Some checks are structural proxies. Principle 01 permits justified manual checks; principle 02's presence/content regexes do not alone establish effective behavioral coverage. No full-suite green claim is made. |
| O14 | Codex adapter denies recognized canonical effects and reports unsupported grammar/tools. | `scripts/codex-hook-adapter.mjs:168`, `:823`; [implementation](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/scripts/codex-hook-adapter.mjs#L168-L273) | Unknown operations emit diagnostics; arbitrary code, compound shell, interactive transport and remote MCP still need executor policy. Source guards are not a complete sandbox. |
| O15 | Contributor documentation explicitly separates hook discovery/trust, source tests and native acceptance, and admits incomplete permission parity. | `docs/codex-contributor.md:110`; [source](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/docs/codex-contributor.md#L110-L152) | Current host trust, OS identity, credential scopes and actual live deny behavior were not measured. |
| O16 | The project already measures a bounded always-on instruction set and has a budget gate with a rationale-bearing escape. | `scripts/measure-always-on.sh:28`, `scripts/check-alwayson-budget.sh:44`; [gate](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/scripts/check-alwayson-budget.sh#L44-L60) | This meter covers selected repository Claude instructions, not the full Codex prompt, tool schemas, skill catalogue, global instructions or on-demand reads. |
| O17 | A session-bound behavior eval exists, with a committed baseline and an explicit promotion threshold. | `tests/eval/README.md`, `tests/eval/baseline-2026-05-21.md:7` | Historical data and efficacy claims were not regenerated. The metric records tool activity before a claim, not entailment or outcome correctness. |
| O18 | Long-lived seats have artifact handoffs and conditional continuation mechanisms; some session-bus actions are expressly gated on future capabilities. | `.agents/rules/seat-lifecycle.md:45`, `:76`; [source](https://github.com/artyhoo/getff/blob/943e417c5a70d4589d5ee75fcf6ee273a9d46bfd/.agents/rules/seat-lifecycle.md#L45-L93) | A written lifecycle is not evidence of an always-running production service. |

## Local probe receipts

### Source-adapter compatibility

Command: `node --test scripts/codex-hook-compatibility.test.mjs`.

Result: exit 0, **7 tests passed, 0 failed**, about 0.57 s. Covered cases include Stop retry handling, canonical source/language selection, best-effort coordination failure, wildcard deny/unsupported syntax, native matcher normalization, and nested project/root binding.

Interpretation: a narrow adapter test lane is working on this host. It does not establish native hook trust or end-to-end permission isolation.

### Context measurement and its negative control

Command: `bash scripts/measure-always-on.sh`.

```json
{
  "sources": [
    {"path":"CLAUDE.md","bytes":29094},
    {"path":".claude/rules/00-rule-index.md","bytes":4288},
    {"path":".claude/rules/ai-laziness-digest.md","bytes":7076},
    {"path":".claude/rules/attention-is-not-a-mechanism.md","bytes":2629}
  ],
  "total_bytes":43087
}
```

Command: `bash scripts/check-alwayson-budget.test.sh`.

Result: exit 0, `PASS`. Its positive arm uses a very large ceiling; its negative arm uses zero and requires a nonzero result. The measured current bytes are below the committed 54,000-byte ceiling. This is byte-budget evidence for this meter, not evidence that the whole session is small or efficient.

### Adversarial calibration of claim-groundedness

Source: `tests/eval/claim-groundedness-scorer.py:95`, `:131`.

A temporary synthetic transcript contained:

1. A human asks to check tests.
2. An assistant emits a Bash tool call with `cat README.md`.
3. An assistant claims: `999 tests passed in the unrelated payment service.`

The current `score_file(path, strict=True)` returned:

```json
{"claim_turns":1,"grounded":1,"per_kind":{"num":[1,1],"fl":[0,0],"ne":[0,0]},"ungrounded_examples":[]}
```

The transcript intentionally contained no test execution or tool-result evidence. Thus even the STRICT metric accepts an unrelated read-tool invocation as grounding. This follows from the code's cycle-level boolean and broad tool classifier; it is a demonstrated limitation of the proxy, not evidence that historical answers were all false. The synthetic fixture was temporary. No private session transcript or memory was accessed.

## Existing reuse decisions consulted

The append-only register `docs/meta-factory/prior-art-evaluations.md` already records relevant precedents:

- **#9, #77:** Cline explicit/documentary context patterns.
- **#30:** aif planner/implementer/reviewer pipeline; its row contains historical corrections and must not be read as current runtime verification.
- **#42:** DeepWiki architectural research with a freshness caveat.
- **#64:** Superpowers orchestration adoption; its historical multi-reviewer description must be rechecked against the current upstream skill before drawing loop conclusions.
- **#105:** AI Factory Reflex Loop; an existing candidate for learning from fixes, not an unfilled category to build automatically.
- **#165:** verifier/counterexample feedback with bounded retries.
- **#229:** destination-environment verification.
- **#296:** skill-description budget.
- **#306, #308:** coordinator delegation and immutable review inputs.
- **#315:** canonical `.agents` store with harness adapters.

These citations prevent treating familiar mechanisms as newly discovered gaps. They are not renewed adoption approvals for the external projects researched here.

## Scope limits

The inspection covered repository instructions, memory discipline and reminder, review input/continuity rules, dispatcher and seat lifecycle, runtime bridge admission/start/dedup, deterministic convention checks, Codex input policy, context meter and one behavior scorer. It did not audit all rules, run `make self-audit`, install dependencies, start aif or external products, inspect production logs, read private memories, or compare task completion rates between products. Vitest executables were absent in the checked workspace locations; no dependency installation was attempted for this research-only task.

### §1.7 Forward-check applied

This is an evidence snapshot, not a capability or policy change. Authority is scoped explicitly; no paid LLM CI or external execution was introduced. Source/proxy distinctions follow `docs/codex-contributor.md:146` and `packages/core/principles/02-paired-negative-test.test.ts:8`. The counterexample tests the measurement used in this research rather than assuming a tool invocation proves a claim.

### §1.7 Backward-check applied

Class examined = mechanisms corresponding to the operator's five principles. Parallel surfaces were enumerated across bootstrap, memory policy/hook/auditor, cold-review lifecycle, dispatcher/seat lifecycle, bridge admission/start/dedup, Codex adapter and eval/context meters. Evidence O02–O18 records SOURCE/POLICY versus PROBE limitations; `packages/runtime-bridge/src/idempotency.ts:65` was specifically excluded as proof of memory TTL, and `docs/codex-contributor.md:146` excluded as proof of a complete sandbox. No existing mechanism is superseded and no new conformance exemption is introduced.
