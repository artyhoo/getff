<!-- scope:agent-practices-evidence -->
# Agent practices: evidence package for senior analysis

> **Authoritative for:** the 2026-10-26 research snapshot, source distinctions, comparison hypotheses and proposed measurements below.
> **NOT authoritative for:** adopted product direction, getff policy, permission changes, implementation approval, new spend, or independently measured product superiority.

Status: **research collected; adoption decisions remain open**. This package prepares the requested senior-model discussion. It does not turn a plausible practice into a new rule merely because another project mentions it.

## 1. Read this first

The strongest comparison is between mechanisms at the same layer. getff is convention-enforcement infrastructure with an operator orchestration contour. OpenMausBot is an agent workspace/harness. Hy-Memory is a memory SDK; Tencent MemHub is its persistent collection/recall product. The Grokbot repository is a third-party account plus reusable instructions. None is a drop-in substitute for all the others.

The evidence supports these starting observations:

1. **Several proposed principles already have concrete homes in getff.** Codify-then-pointer memory, explicit authority owners, immutable review inputs, scoped plan admission and durable handoff state are present. Their presence does not establish universal compliance or deployed effectiveness.
2. **The external systems do not support an unconditional fresh-session rule.** Both the Grok account and OpenMausBot preserve history. OpenMausBot intentionally resumes native sessions and keeps Claude processes warm. Fresh worker, fresh process and fresh model context are different things.
3. **The most concrete import candidates are lifecycle/approval/recall contracts, not a large bot roster.** OpenMausBot supplies inspectable crash recovery, request fencing and exact routine-operation receipts; Hy-Memory supplies temporal relations, conflict states and coding experience links. Both have meaningful limits.
4. **getff's strongest relative evidence is executable convention machinery versus the Grok note pack's prose.** This does not prove a better general assistant, lower task cost, better memory or superior product outcomes.
5. **Measurement is a real weak point to carry into analysis.** The local claim-groundedness scorer accepts an unrelated README read as grounding for a made-up test-success claim, even in STRICT mode. It measures a tool-use proxy, not factual correctness.

## 2. Evidence map and reproducible pins

| Surface | Immutable input | Evidence class and limitations | Detailed dossier |
|---|---|---|---|
| Own project | `artyhoo/getff@943e417c5a70d4589d5ee75fcf6ee273a9d46bfd`, 2026-10-26 | Local source inspection; two narrow test/probe lanes and one synthetic counterexample. No full self-audit or production comparison. | [Own-project observations O01–O18](2026-10-26-agent-practices/own-project.md) |
| Grok field notes | `unicodef1wn/grokbot-field-notes@02780c04ef5f412b28573bce6f82afd15d195d1f`, 2026-09-20 | Third-party prescriptions/accounts, not official xAI code or independently verified stream/product behavior. | [18 findings, contradictions, inventory and experiments](2026-10-26-agent-practices/grok-notes.md) |
| OpenMausBot | `milind-soni/OpenMausBot@0d8eacc65cd3b783a0d28d019d39e6367780b911`, 2026-10-25; package 0.1.127 | Implementation and tests inspected. External code/tests/native CLIs were not executed. | [OMB-01–OMB-25](2026-10-26-agent-practices/openmausbot.md) |
| Hy-Memory / Tencent MemHub | `Tencent-Hunyuan/Hy-Memory@1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41`, 2026-10-26; SDK source 2.0.5 | SDK, current MemHub cutover, tests and three research papers inspected. No runtime or benchmark reproduction. README install still names SDK 2.0.4. | [H01–H25](2026-10-26-agent-practices/hy-memory.md) |

Source links in the four dossiers are revision-pinned. Local source snapshots were kept under `/tmp/agent-practices-2026-10-26/` as research scratch; they are not portable deliverables. The appended inventories and pinned URLs identify how to retrieve the inspected material again. Retrieval date is not evidence that a deployed binary matches the source SHA.

Evidence labels throughout: **mechanism** = inspected implementation; **policy** = stated instruction; **account** = third-party or author-reported observation; **probe** = actually executed named local check; **candidate** = hypothesis for later evaluation; **unknown** = evidence not collected.

## 3. Discovery tools were used, and corrected against source

DeepWiki structure and targeted questions were used for all three external repositories. Context7 exact resolution worked for `/milind-soni/openmausbot`; exact Grok notes and Hy-Memory resolution produced unrelated libraries. No unrelated result was silently substituted. Context7 `/obra/superpowers` was also queried to check own-stack session/review precedent.

These tools exposed useful navigation but demonstrable drift:

- **Grok notes:** DeepWiki implied an available verification executable. The pinned pack says adopters must supply their own commands; its only Python code generates Cursor rules. See Grok findings 1–2.
- **OpenMausBot:** Context7 said peer-started Full becomes Auto. Current `approvalModeForOrigin` downgrades Custom, preserves other modes, and Chief lineage can raise a teammate's level. See OMB-11. DeepWiki also oversimplified warm Claude invalidation; volatile notes do not necessarily restart its process, OMB-02.
- **Hy-Memory:** DeepWiki explained an older governance architecture and missed the current SDK-authority data plane and three-day raw retention. The MCP acronym was also expanded incorrectly. See H16, H21–H22.

Accordingly, neither tool output nor agreement between tools counts as deployment verification. Raw code owns the specific implementation claims; papers own their reported experiments; field notes own only what their author recorded.

Two general primary sources were consulted as counterchecks. Anthropic's [context-engineering article](https://www.anthropic.com/research/effective-context-engineering-for-ai-agents) treats compaction, durable notes and delegated context as situational tools. Its [effective-agents article](https://www.anthropic.com/research/building-effective-agents) treats added agent complexity as a performance/cost trade-off. Its [evals article](https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents) distinguishes evaluation components and outcomes. These are vendor guidance, not independent proof for this project's workload.

## 4. The operator's five principles: where they hold and need correction

| Principle | Supported part | Necessary correction | Evidence / experiment that could change the conclusion |
|---|---|---|---|
| Fresh session per task plus explicit knowledge | Bounded tasks and durable inputs make restart and independent review easier. getff already has snapshot/watch-list and handoff patterns. | Prefer a fresh bounded worker for a new independent task; do not reset every repair turn automatically. Warm process, native session, app conversation and task identity are separate. A resume can preserve valuable tool state. | O06–O08; OMB-02–05, OMB-17; Grok findings 5–7. Compare fresh worker + artifact packet, resumed worker and cold process + native resume on matched tasks. Reject an unconditional rule if resets increase lost requirements, repeat effects or accepted-task cost. |
| Memory is an index of experience; code and ADRs outrank it; carry sources/date/lifetime | Repository conventions should not live solely in private recall. Memory should not grant authority or override current instructions. | Code describes actual behavior; an approved ADR/spec describes intended decisions. A conflict needs reconciliation, not automatic supremacy of whichever is easier to read. Date and TTL do not establish truth. Use version/source validity and supersession; stable preferences may need no fixed expiry. | O03–O05; H02–H13; OMB-24–25. Seed an obsolete ADR, current code bug and stale recalled policy; check whether the agent identifies the conflict rather than silently treating observed code as intended policy. |
| Result-verification loop before adding a second agent | A runnable oracle and explicit completion evidence can catch concrete faults without buying another opinion. | A check can encode the wrong criterion, omit the user's outcome or be a weak proxy. Independent requirements/architecture review may be useful before implementation. Order by uncertainty and risk rather than a universal ban on a second agent early. | Local scorer counterexample; O13/O17; Grok findings 1–4, 16; OMB-23. Use a 2×2 trial of result oracle and independent reviewer; blind-grade held-out user outcomes and incremental defects per human minute. |
| Agent has its own rights; read and act separated in code; dangerous actions need confirmation | Effective executor restrictions and action-specific authorization are stronger than role prose or model self-restraint. | Own bot identity is not necessarily an OS principal, separate credential or least privilege. Read access can itself disclose private data; network submission is an effect. Approval must bind operation, target, authority, version and validity, and must be checked at the actual executor. Use already delegated scope rather than repeatedly asking for harmless actions. | O10/O14–15; OMB-10–16, OMB-22; H16–H20. Test origin × tool × target × change/replay/revocation, using dummy data. A UI card or VM alone fails the principle if the actual process still has broader authority. |
| Persistent managing layer delegates to disposable executors | Durable task ownership, state, requests and recovery can outlive any worker. | Persistent should describe recoverable state/service identity, not an immortal LLM transcript. The coordinator itself can be replaceable. A fixed single-agent workflow may be cheaper for small work; bot teams are not mandatory. | O08–O12/O18; OMB-07–09; Grok finding 6. Hy's write coordinator is a memory service, not an engineering-manager analog (H14). Kill the manager/worker between state transitions and verify safe recovery without lost or duplicate effects. |

The broad direction is coherent. The overreach would be turning every row into an absolute: no history, TTL on everything, a second agent always later, confirmation on every write, or an LLM manager for every task. The available evidence does not establish those absolutes.

## 5. What already exists and is not an obvious gap

| Need | Existing getff mechanism | Status of comparison |
|---|---|---|
| Explicit project truth and decision ownership | README authority, bootstrap pointers, per-document authority scope; O01–O02 | Already concrete. A larger generic AGENTS.md or bot persona pack would duplicate knowledge rather than fill an observed gap. |
| Memory as pointer rather than private policy | Codify-then-pointer, SHA reference, reminder hook and reporting auditor; O03–O05 | Semantically aligned with the operator's principle. Do not mislabel a reminder as enforced two-store consistency. General provenance/TTL for every recalled fact remains unverified. |
| Fresh independent review and context continuity | Pinned inputs, narrow fresh review, watch-list and resume exception; O06–O07 | More specific than a blanket fresh-session slogan. Empirical cost and quality remain workload-dependent. |
| Reproducible verification and anti-tautology | Convention checks, firing contracts, negative controls, generated-rule provenance; O13 | Real assets already exist. Some meta-tests check structure; full effect coverage was not established. |
| Bounded implementation admission | Paused claim/release, scoped contract, exact PlanReview binding and reread; O09–O11 | Existing code handles a real version/approval problem. OpenMausBot's routine receipts are an adjacent reference, not a reason to replace this boundary. |
| Persistent orchestration state and handoff | aif/task/PR/git journals, pending result obligations, retry caps, seat handoff; O08/O18 | Existing operator machinery. Operational uptime, exactly-once effects and every continuation path still need live evidence. |
| Dispatch duplicate suppression | Content hash, 24-hour TTL and pruning; O12 | Present, but narrower than a transactional external-effect ledger. Memory retention and event/action deduplication must not be conflated. |
| Instruction cost controls | Bounded source meter, 54,000-byte ceiling and negative control; O16 | Already exists. This session measured 43,087 bytes for that meter's four selected sources; no full-Codex-token conclusion follows. |
| Behavioral measurement | Session-bound claim scorer and baseline/promotion threshold; O17 | Present and worth recognizing, with the demonstrated grounding-proxy limitation. Adding an evaluation system from scratch is not the first inference. |

Relevant existing reuse register entries: **#9/#77** explicit-memory patterns; **#42** DeepWiki/freshness; **#64** Superpowers orchestration; **#105** Reflex Loop; **#165** verifier feedback; **#229** destination verification; **#296** description budget; **#306/#308** coordinator delegation and immutable inputs; **#315** canonical `.agents` adapters. These are cited to avoid rediscovering own-stack work, not treated as immutable proof that upstream still behaves the same way.

## 6. Where a bounded "better" claim is defensible

| Dimension | Supported relative advantage | What cannot be inferred |
|---|---|---|
| Enforcement versus the Grok notes | getff has executable convention machinery; the pinned note pack describes a verification interface adopters must implement. O13 versus Grok finding 2. | That getff beats xAI's unpublished implementation or creates better products. |
| Review provenance versus ordinary role prompts | getff explicitly binds cold inputs to revisions and distinguishes blind review from author narrative. O06–O07 versus Grok finding 4's unspecified independence. | That more reviews improve net throughput, or that every getff review is truly independent and correct. |
| Repository policy versus memory-only steering | getff explicitly moves durable conventions into shared versioned artifacts and reduces private memory to pointers. O03–O05 versus Grok findings 5/8. | That every remembered fact should enter the repo, or that getff has better semantic retrieval than Hy-Memory. |
| Lifecycle success versus acceptance | getff's dispatcher explicitly says DONE/success is not installed acceptance, CI or merge. O08 versus OMB-23's inspected operational-completion branch. | That OpenMausBot has no optional verification features, or that getff's actual result acceptance is flawless. |
| Native execution restrictions | No broad superiority claim is supported. getff openly documents bounded policy parsing; OpenMausBot has detailed requests/receipts but permissive modes; MemHub has actual broker grants. | A complete sandbox or least-privilege deployment for any of them, without testing the actual runtime/configuration. |

This is deliberately narrower than declaring one project globally better. No common task corpus, failure budget, production telemetry or measured operator effort was available.

## 7. Candidate additions, priority and falsification

Priorities below are **discussion candidates**, not adopted rules or implementation orders. **P0** means a prerequisite to trusting a claimed result/authority boundary, not a newly discovered production emergency. The senior model should select by observed workload and avoid reopening already settled scope without new evidence.

| Candidate | Priority and trigger | Reuse / smallest change to evaluate | How to check effect and what would falsify the benefit |
|---|---|---|---|
| C1. Evaluate accepted task outcomes, not only tool-use grounding | P0 when using the existing scorer to justify quality or more autonomy | Extend the existing measurement contour with a small held-out task set and actual outcome oracle. Keep the old proxy named as a proxy; do not replace it with another self-report. Own precedent #165, current O17, Grok 1–4/18, H23–24. | First calibrate claim/evidence entailment against independent labels and seeded unrelated-tool cases. Then track blind acceptance, escaped faults/reopens, human minutes, latency and cost per accepted outcome. Falsified if the new score improves while held-out correctness does not. |
| C2. Verify the effective read/action boundary in the deployed harness | P0 before relying on separation for sensitive reads or consequential actions | Test current executors/credentials/grants; use OMB exact-request and MemHub broker examples as references. Existing scoped plan checks stay in their scope. No permission configuration changes are authorized by this dossier. | Dummy-source tests across native tools, shell/code mode, MCP and child origins; include stale card, changed target, revocation and repeated call. Count actual bytes released and state changes, plus legitimate-task blocks. Falsified by any unauthorized effect, or friction without meaningful boundary improvement. |
| C3. Bind consequential approvals and recovery to exact operations | P1 when actions survive reconnect/restart or can change after review | OMB-15/16/19 provide concrete request-generation, operation fingerprint, version and receipt patterns. Compare to existing O10/O12 before adding anything. Prefer the current owning runtime's extension over a second coordinator. | Review X, mutate payload/target/version, reconnect after commit before acknowledgment and repeat. Expect changed requests to require renewed authorization and exact retries to return the original result. Falsified if effects duplicate or modified operations inherit old approval. Do not equate ingress dedup with downstream exactly-once behavior. |
| C4. Give recalled experience an inspectable validity contract | P1 when stale/cross-project recall causes repeated errors | Prefer existing recall/MCP surface before embedding Hy-Memory. Evaluate source URI/revision, observed event time, scope, supersession and review condition. OpenMausBot's dated notebook is the simpler comparison; Hy's chain model is the richer one. | Seed A→B→retraction, wrong branch/subject, missing evidence and raw expiry. Measure current-answer correctness, usable citations and wrong actions. Falsified if metadata is merely stored but unavailable to consumers, or stale facts still drive actions. A blanket fixed TTL is not required. |
| C5. Make coordinator restart/child lifecycle evidence explicit | P1 only where current aif/operator recovery has a measured failure | Compare existing bridge/task journal with OMB-07–09/18/20. Borrow state transitions, not the entire workspace product. | Fault-inject before claim, after child launch, after external commit and before receipt; observe orphan work, repeat effects, stuck tasks and manual recovery minutes. Falsified if complexity increases without reducing those failures. |
| C6. Choose fresh versus resumed context empirically | P2 after a matched baseline; higher if history contamination is observed | Reuse current watch-list/snapshot/handoff, SSOT #64/#308. Compare native resume and canonical artifact reconstruction rather than imposing universal resets. | Counterbalanced repeated task/repair sequences with fixed model, scope and environment; measure lost requirements, regression escapes, repeated actions, token/cache accounting and human time. Falsified if freshness improves cleanliness but worsens accepted-task cost or loses essential tool state. |
| C7. Prune operational instructions using held-out behavior | P2 when measured bootstrap/tool-reading burden is material | Existing context/description budgets already provide a home. Grok's skill-generalization and narrow-roster advice is a hypothesis; preserve incident evidence in cold records. | Compare minimal routed instructions to current loading on unseen tasks. Count rule violations and accepted outcomes along with bytes/tokens and latency. Falsified if trimming saves prompt size but loses important constraints, or token savings disappear after repeated rediscovery. |

A practical first evaluation can use 20–30 representative tasks as an **exploratory** set, plus targeted negative cases. That sample is a planning suggestion, not a significance guarantee. Freeze model/provider versions, task inputs, repository revisions, environment and budgets; randomize/counterbalance assignment; report failures and human interventions. API/model expenditure, new recurring jobs and production writes require their own authorized scope.

## 8. What not to import wholesale

These are provisional exclusions from an implementation plan, based on problem-class mismatch or insufficient effect evidence:

- **A large roster/persona pack.** Named bots can make routing legible, but do not create isolation, correctness or expertise. The notes themselves warn about roster sprawl and attention cost (Grok 17). getff already has named roles and owners.
- **The Grok note pack as superior executable enforcement.** It is a useful failure/workflow catalogue. Its verification executable is a proposed interface, not a shipped artifact (Grok 2). Keep actionable examples; do not replace checks with more prose.
- **Full access defaults or Chief privilege propagation.** They do not implement the operator's least-authority principle. OpenMausBot's detailed permission machinery should be studied separately from those defaults (OMB-10/11/22).
- **A VM as proof of end-to-end confinement.** Computer tools and the host CLI process can have different boundaries. Worktrees solve file/branch concurrency, not credential or network isolation (O09/O15, OMB-22).
- **Hy-Memory as an unquestioned source of project policy.** Its own MCP guidance treats memories as historical context; reconciliation is model-driven, can degrade to duplicate additions, and public evidence expansion is incomplete (H04/H06–H13).
- **Automatic extraction of all history as the default improvement.** Wrong-subject merges, deletion lineage, debug logs, source deletion and retention create specific obligations. Current adapters do not guarantee that deleting original history removes derived memories (H08/H10/H15/H20/H21).
- **A whole replacement harness or memory stack without an outcome pilot.** OpenMausBot offers much more product surface than convention enforcement; full MemHub adds a service, storage engines, model processing and host integration. A narrow connector/contract evaluation is a different commitment from adopting the application (OMB units table, H01/H25).
- **PR count, bot count, memory count or recall score as proof of engineering success.** The notes describe a zero-revenue game with serious launch failures; the papers measure specific tasks and protocols, not this project's cost/quality (Grok 15–18, H23–24).
- **Another reviewer by default for every problem.** getff already has review machinery. Add a seat only when it detects independent failures enough to justify its cost; do not infer that a second model fixes a bad oracle (O06/O17, OMB-23).

Licenses recorded by the sources: Grok notes MIT; OpenMausBot Apache-2.0; Hy-Memory Apache-2.0 with exclusions/third-party terms. These are source metadata, not a legal compatibility verdict. Any concrete code reuse must retain and review applicable notices, dependencies and assets at its selected revision.

## 9. Important contradictions and unresolved claims

| Claim a reader might be tempted to make | Evidence blocking it |
|---|---|
| "The Grok team proves fresh sessions beat history." | The account describes long-lived per-bot memory; no controlled comparison exists in the inspected notes. |
| "Grok bots have a known shared-memory architecture." | PRODUCT says no sharing except messages; the PM playbook describes an additional shared pool. The note pack does not resolve this contradiction. |
| "OpenMausBot restarts processes, so context is disposable." | Codex `thread/resume`/`ephemeral:false` and Claude warm/native resume deliberately retain session state. |
| "OpenMausBot completion proves an independently checked outcome." | The inspected coordinator settles an OK uncapped turn without pending questions/cards; mandatory independent correctness review is not present at that branch. |
| "Hy provenance fields mean the user can always inspect the original source." | Current SDK public search omits the raw anchor, MemHub recall returns empty evidence IDs, and raw retention is three days. Derived facts can outlive original evidence. |
| "Hy temporal memory applies TTL to all facts." | Working facts explicitly have no TTL; expired intentions can be demoted to historical facts rather than deleted. |
| "The Hy papers establish lower cost and better coding for getff." | Benchmark tasks/protocols differ; full artifact reproducibility was not established. Writer-report subsamples and QA results cannot be generalized to full execution success. |
| "getff's no-bypass thesis is already a security sandbox guarantee." | Source docs explicitly limit the Codex parser/adapter; hook trust and native acceptance are separate. Some mechanisms are advice, structural checks or conditional/gated lifecycle steps. |
| "Our scorer's grounded-rate establishes factual reliability." | The executed unrelated-tool counterexample is scored grounded even in STRICT mode. |

## 10. What is not verified, and what to request only if it changes a decision

1. **No independent Dots or actual Grok Bot product inspection.** Dots was context in the request, not a specified source. No closed-source implementation, account behavior or original livestream was accessed. Do not rank those products from the note pack.
2. **No comparable production outcome data.** To choose a harness, obtain the operator's actual task mix, success/reopen data, manual intervention time, recurring workload and desired UI/remote-access needs. To discuss principles now, those missing data do not block the source comparison.
3. **No current installed MemHub identity/version audit.** Matching tool vocabulary does not prove that the operator's memory service is this source revision. Private memories were not queried.
4. **No deployed permission proof.** Need exact host configuration, native binaries, credential principals/scopes and a harmless sandbox probe before promising separation. No security changes were made here.
5. **No external runtime/test execution or paper replication.** Inspected tests are intended contracts. CMB histories/images/eval artifacts and writer-report sampled IDs were not reproduced; no statistical superiority is claimed.
6. **No complete source audit.** The dossiers enumerate close reads and topic searches. Unread files, generated ports, media and optional product paths remain outside the conclusions.
7. **No integration cost estimate or legal conclusion.** Code dependencies, maintainability and license obligations need a specific unit/version and pilot scope.

## 11. Verification receipts from this session

- Own input revision and clean initial checkout were measured with `git rev-parse HEAD`, `git status --short`, and `git show -s`.
- `node --test scripts/codex-hook-compatibility.test.mjs`: **7 passed, 0 failed**. This is source-adapter evidence, not native trust/activation.
- `bash scripts/measure-always-on.sh`: **43,087 bytes** in its selected four sources. The meter deliberately excludes many other context channels.
- `bash scripts/check-alwayson-budget.test.sh`: **PASS**, including an over-ceiling negative control.
- Existing Python scorer on a temporary synthetic transcript: **1 claim, 1 grounded** after an unrelated `cat README.md`, with no test execution. This falsifies entailment interpretation of that score.
- External sources were retrieved as text/archive/PDF, inspected and citation-pinned. No downloaded source programs, external tests, agent runtimes or paid model API were launched.
- Document validation checked **205 pinned source references across 110 unique text files**, including cited line bounds and relative dossier links. The PDF citation was kept outside text-line validation. Central permission, receipt, recall, retention and field-note contradiction claims were additionally read against their raw source excerpts.

Full self-audit/typecheck/Vitest was not run; checked workspace locations had no Vitest executable. Dependencies were not installed for a research-only document change. No PR, policy change or deployment is part of this handoff.

## 12. Research self-application and next-model brief

Active traps from `.agents/rules/ai-laziness-traps.md`: **T2/T3** distinguish source/probe from proposed checks; **T4/T7/T10** enumerate source strata and run counterchecks; **T5** keep fixes out of research; **T11/T12/T13/T16** check own-stack and problem-class match; **T14** preserve coverage limits; **T15** test this package's own truth proxies; **T20** attach evidence/falsifiers to candidate priorities. **T19** means this package must not be used as a self-issued acceptance/adoption verdict; the requested independent senior analysis still remains to be done.

Domain traps added for this research:

- **T-AP-A — product-story laundering:** treating a third-party stream extraction as verified xAI architecture or causal outcome evidence.
- **T-AP-B — schema laundering:** treating a provenance/expiry/approval field as proof it is populated, exposed to recall and enforced at the effect boundary.
- **T-AP-C — process/session conflation:** treating a fresh OS process or task card as a fresh native model context.
- **T-AP-D — superiority by layer mismatch:** comparing convention tests against assistant UI/memory breadth and declaring one whole project better.

Adversarial questions actually followed through: "Could our purported quality meter accept irrelevant evidence?" produced the local counterexample. "Do the cited systems actually reset task context?" found persistent native sessions. "Does a provenance-rich schema guarantee source recoverability?" found omitted anchors/empty evidence IDs and short raw retention. "Which claim lives only in a story or prompt?" separated the Grok verification interface and OpenMausBot retry notes from executable mechanisms. These findings are why the package's favorable observations remain bounded.

### §1.7 Forward-check applied

This is an append-only evidence document plus source dossiers. It changes no executable convention, runtime permission, upstream adoption register or project goal. The scope follows `README.md`'s enforcement-product/operator distinction and `CLAUDE.md:36`'s documentation exemption from capability commits. Existing reuse IDs in section 5 prevent proposing already-owned mechanisms as missing. Source/probe/policy boundaries were checked against `docs/codex-contributor.md:146`; candidate benefits all have explicit falsifiers. C1–C7 remain provisional until senior analysis and workload evidence select a concrete authorized change.

### §1.7 Backward-check applied

Class of this research = claims about context, knowledge authority, verification, permission boundaries and persistent orchestration. Surfaces examined extend beyond this document: bootstrap and authority owners; memory rule/hook/auditor; snapshot/watch-list/review lifecycle; dispatcher and seat journals; bridge scope/start/dedup; Codex effect parser; context meter and behavior scorer; all three external source families and research papers. Per surface, the evidence tables retain PRESENT/PARTIAL/UNKNOWN boundaries instead of declaring compliance. `packages/runtime-bridge/src/idempotency.ts:65` was not counted as memory TTL, `scripts/codex-hook-adapter.mjs:205` was not counted as complete sandboxing, and `tests/eval/claim-groundedness-scorer.py:95` was adversarially probed rather than trusted by its name. No existing artifact is superseded; no adopted rule has a new backward migration obligation in this research-only change.

### Brief for the senior-model discussion

Read sections 1, 4–9 and the own-project dossier first. Open source dossiers when a verdict depends on their implementation detail. Treat every candidate as revisable. Preserve the distinction between the enforcement product and the personal operator contour. For each selected addition, state: observed gap, exact existing mechanism, external reusable unit, smallest experiment, acceptance metric, cost/maintenance burden and what would reverse the recommendation. Explicitly classify existing adequate work, bounded stronger work, and unnecessary imports. Challenge both the operator's absolutes and source-author success stories. Do not create a new harness, policy, memory migration or implementation plan solely because the sources make it sound attractive.
