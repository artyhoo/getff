<!-- scope:agent-practices-evidence -->
# Hy-Memory and Tencent MemHub: evidence dossier

> **Authoritative for:** Source evidence for Tencent Hy-Memory and MemHub at the immutable revision named below.
> **NOT authoritative for:** adopted getff policy, independently verified production outcomes, or the operator's installed service.

Portable handoff note: source links below are pinned and durable; absolute `/tmp/agent-practices-2026-10-26/` paths identify temporary research snapshots, not files shipped with this dossier. The source-specific path inventories and immutable URLs allow reconstruction after those temporary files expire.


Research date: 2026-10-26. Scope: source and published research inspection only; no installation, untrusted code execution, tests, model calls, or queries against the operator's memory service. This is an input to senior analysis, **not an adoption verdict**.

## Identity, pin, access and evidence quality

- Repository: `Tencent-Hunyuan/Hy-Memory`, pinned to **`1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41`**, authored/committed 2026-10-26 01:10:22 UTC. Commit message: “fix(memhub): make the SDK memory page one consistent page” (merge #176). [Immutable commit](https://github.com/Tencent-Hunyuan/Hy-Memory/commit/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41).
- GitHub connector was used first: commit, recursive tree, README, LICENSE, `memhub/LICENSE`, `memhub/README.md`, SDK extractor/reconciler, `pyproject.toml`. Recursive tree returned **1,809 entries**, `truncated=false`. Guessed `hy_memory/types.py` returned 404; actual models are `hy_memory/models/memory.py` and `hy_memory/coding/types.py`.
- For efficient line-level inspection, downloaded the exact-SHA codeload archive, extracted **1,701 non-media/non-lock regular files** under `/tmp/agent-practices-2026-10-26/hy/source`. `hy/download.json` records URL, SHA and archive size (17,941,440 bytes). No source programs were executed. PDF papers were separately fetched, then text-extracted with the bundled `pypdf` library.
- DeepWiki `read_wiki_structure` confirms SDK, storage, coding, MemHub core/host bridge, tests and governance coverage. Two targeted questions were asked. **Consequential mismatch:** DeepWiki answered the SDK-authority question using old `GovernedRecallTarget`/`MemoryProcessingSupervisor`, did not know `sdk_memory_runtime.py`, and said no three-day retention evidence. Raw pinned code contains `SdkRecallTarget`, the new write coordinator and three-day retention. Treat this wiki as stale navigation, not evidence for current guarantees. Q links: [architecture](https://deepwiki.com/search/identify-exact-source-files-fo_bc54a491-962d-4991-aa08-3fec1b4e29cc), [cutover](https://deepwiki.com/search/at-sdkauthority-cutover-sdkmem_d6a91cfd-1071-43b9-9415-d402e6eb3bf7). It also incorrectly expanded MCP as “MemHub Control Protocol”.
- Parent attempted exact Context7 lookup and received unrelated matches; no substitute library was treated as Hy-Memory documentation.
- PDF access: pinned CMB GitHub page was accessible but exposed no paper text; raw PDF fetched successfully. arXiv v1 PDFs `2606.09483v1` and `2610.22196v1` fetched successfully. `pdftotext` missing; `pymupdf` missing; bundled `pypdf` succeeded. Local `cmb.txt`, `dcpm.txt`, `writer.txt` contain explicit page markers.
- Tencent MemHub is the product **inside this repository**, historically named One Memory (`one_memory`, `~/.one-memory`). Do not conflate it with other projects called MemHub. Tool descriptions exposed in this operator's environment use matching `MemHub_*` vocabulary, but **no running-service identity, installed version, account state or data was inspected**; matching names do not prove its deployment is this SHA.

## Concrete claims

Every source link below is immutable. `Mechanism` means inspected code, `Contract` means product documentation, and `Research` means author-reported paper evidence. A schema field alone is not proof of its population or correctness.

### H01 — Three different reuse surfaces exist

**Mechanism/contract.** Python SDK owns memory; MemHub adds a FastAPI management service, queue, host integrations, CLI, React UI and Electron shell. The root package is `hy-memory` **2.0.5**, while root quick-start still installs **2.0.4**. MemHub pins 2.0.5 and identifies itself as 1.0.5/preview. This matters for reproducible integration: README install snippets and this source pin are different versions. [SDK package lines 5–23](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/pyproject.toml#L5-L23), [root quick start](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/README.md#L63-L74), [product boundary](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/README.md#L37-L55).

### H02 — Chat memory schema can encode provenance and temporal change

**Mechanism.** `MemoryNode` separates user/agent/session/source, owner, event time (`memory_at`), validity interval, creation/modification times, supersession links, confidence/source type, raw anchor and evidence chain. Explicit/inferred/composite and active/superseded/negated/conflicted/shadow/archived are represented. These are useful representational affordances, not verified truth or evidence calibration. [Model lines 121–145](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/models/memory.py#L121-L145), [fields 244–322](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/models/memory.py#L244-L322).

### H03 — Event time is distinct from ingestion time, with default-local-clock behavior

**Mechanism.** Creation/modification and default `valid_from` use `datetime.now()`; `memory_at` stays absent unless supplied. Public serialization uses Unix timestamps. Consumers cannot equate write time with when a remembered event happened, and timezone-naive ingestion deserves an experiment. [Defaults and serialization](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/models/memory.py#L330-L344), [timestamp fields](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/models/memory.py#L419-L436).

### H04 — Internal provenance does not imply source-text auditability at public recall

**Mechanism.** SDK public search deliberately omits `source_raw_memory_id`: the code says raw nodes cannot be read through that public path. Source and event/write times remain. Current MemHub `SdkRecallTarget` returns `evidence_ids=()` and `scopes=()`, and labels `updated_at` from creation time. A consumer must not promise source quotations or independently checked evidence just because the storage schema has anchors. [SDK output](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/client.py#L3220-L3241), [current recall output](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/recall.py#L242-L272).

### H05 — Automatic extraction and explicit pre-extracted learning share reconciliation

**Mechanism.** Chat extraction asks an LLM for memories, intentions and basic information. Product write processing calls `add` for raw conversation and `add_extracted` for already-extracted content. `add_extracted` skips extraction **but still reconciles**. Explicitly saving a lesson therefore does not establish an immutable rule; reconciliation can alter stored state. [Extractor](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/agent/extractor.py#L1-L11), [write branches](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/sdk_write_processor.py#L35-L90), [pre-extracted path](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/client.py#L3028-L3040).

### H06 — Contradiction handling uses model-decided state transitions

**Mechanism.** Reconciler invokes the LLM, parses ADD/UPDATE/SUPERSEDE operations and the writer applies them. SUPERSEDE marks previous nodes superseded and builds a chain; legacy DELETE maps to shadow-only update. Some UPDATE batches modify the durable node in place, so README “immutable versioned records” is not universal write-once history. [LLM reconciliation](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/agent/reconciler.py#L1380-L1402), [in-place update](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/pipelines/writer.py#L1369-L1409), [state handling](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/pipelines/writer.py#L1595-L1642).

### H07 — Reconciliation failure can retain contradictory duplicates

**Mechanism.** Unavailable/invalid reconciliation falls back to adding every extracted memory, returns success when nonempty and records a degraded flag/reason. This preserves content but does not resolve conflicts. An upstream “write succeeded” is insufficient evidence that the new fact superseded the old one. [Fallback](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/agent/reconciler.py#L1471-L1482). Failure example: “use Node 24” and “use Node 26” both remain after malformed reconcile JSON.

### H08 — Explicit deletion can reactivate an older belief

**Mechanism.** `async_delete` repairs evolution chains before deleting; deleting the head can restore its predecessor to active/latest. Vector and graph operations can complete partially, with success reflecting store completion. Deleting an incorrect new preference is not equivalent to forgetting the entire preference lineage. [Delete contract and implementation](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/client.py#L4443-L4528). Failure example: deleting “current employer B” can expose prior employer A as active.

### H09 — Intention expiration demotes rather than forgets

**Mechanism.** The proactive read lane fetches active latest L7 entries, then changes expired entries to L2 historical facts. It returns immediately with no work if `limit<=0`; expiration is lazy and best effort. This is temporal routing, not a universal TTL deletion guarantee. [Code](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/pipelines/_retrieval/intention.py#L279-L338).

### H10 — Working/coding facts have no TTL and an optional identity guard

**Mechanism.** Working facts rely on semantic recall and model supersession, explicitly have no TTL; fact/experience links preserve derivation. Exact-subject guard defaults **off** because unstable free-text subjects block valid updates; comments acknowledge cross-subject merges can return. [Design/data](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/coding/types.py#L143-L178), [actual default](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/coding/fact_reconciler.py#L160-L179). Failure example: similar deployments on two machines can be interpreted as successive states of one task.

### H11 — Reusable experiences carry applicability hints, not enforced preconditions

**Mechanism.** Experiences include `boundary_envs`, confidence, workspace/branch, files, source facts and timestamps. `boundary_envs` is text for the consumer to assess; schema presence does not prove runtime compatibility enforcement. Branch filtering requires workspace, and legacy null branches remain eligible. [Experience schema](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/coding/types.py#L83-L115), [search scope semantics](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/client.py#L1846-L1852).

### H12 — Exact code evolution complements lossy summaries, within explicit budgets

**Mechanism/contract.** Coding diff chains attach revision evidence to retrieved facts rather than choosing facts themselves. The renderer limits instructions, block size, revisions and chains. Fact history details also have a 4,000-character inherited budget and 1,200 per predecessor; summaries are limited to 600 tokens. This gives an inspectable loss boundary, not arbitrary-history fidelity. [Chain defaults](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/coding/chain_store.py#L64-L90), [detail budget](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/hy_memory/coding/fact_reconciler.py#L56-L85), [root architecture](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/README.md#L228-L235).

### H13 — Read authority is explicitly weaker than instruction or approval authority

**Mechanism: emitted host guidance.** MCP initialization/tool descriptions say memories are historical context, cannot override the current user, and agent reports or pipeline confirmation do not prove user approval. They distinguish empty from unavailable, results returned from sources actually used, and prohibit bypassing a denial. This is good trust-boundary vocabulary, but remains model-facing guidance rather than proof every consumer obeys it. [Instructions](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/packages/host-bridge/src/mcp-session.ts#L67-L85).

### H14 — MemHub is a persistent memory service, not a general project executor

**Mechanism/contract.** Runtime survives UI exit, uses a system service/LaunchAgent, and Core owns scanning, queue draining and SDK writes. `SdkWriteCoordinator` resolves a profile and executes one write; it does not assign software-delivery work or approve project outcomes. “Coordinator” here must not be imported as evidence of an autonomous multi-task engineering manager. [Lifecycle](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/README.md#L99-L113), [coordinator](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/sdk_write_processor.py#L115-L149), [drain](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/api.py#L1216-L1265).

### H15 — Collection is adapter-based and source capability matters

**Mechanism/contract.** Product promises no screen/AXTree/OCR/keyboard/clipboard/audio collection. Codex adapter reads selected rollout JSONL roots, skips reasoning/system/developer envelopes, and declares it **cannot observe deletes or reconcile a complete set**. Deleting source history need not mean imported memory disappears. [Collection promise](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/README.md#L39-L44), [Codex adapter](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/imports/sources/codex.py#L29-L75), [exclusions](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/imports/sources/codex.py#L90-L124).

### H16 — Permission boundaries are separate, but old governance claims do not transfer

**Contract plus current mechanism.** Current architecture separates source-root grant, sync switch, model-content permission and host recall grant, explicitly saying host grant is **not a per-memory cross-harness ACL**. Current invocation gate serializes sedimentation/source checks immediately before HY invocation. This supports admission control; it does **not** establish the old supervisor's claimed per-network-request rechecks after cutover. [Permission contract](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/docs/ARCHITECTURE.md#L145-L157), [current gate](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/api.py#L1201-L1214). In-flight revocation/remote-request behavior remains an explicit unknown.

### H17 — Host bridge enforces grants independently from tool descriptions

**Mechanism and inspected tests.** Broker authenticates installations and checks tool/scope grants; calls verify permission again before release. Tests cover live grant changes, invalid scopes, corrupt grants, credential isolation and redirect refusal. Workspace comes from the host entrypoint, not a model-provided directory. Tests were read, not run. [Host-derived workspace](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/packages/host-bridge/src/mcp-session.ts#L92-L101), [broker call/recheck](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/packages/host-bridge/src/recall-broker.ts#L382-L397), [live revocation test](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/packages/host-bridge/src/host-broker-permissions.test.ts#L369-L415).

### H18 — Local storage and local embeddings do not imply local extraction

**Mechanism/contract.** Product sends authorized content to a chosen third-party model. Runtime injects ONNX embeddings and local Chroma/Kuzu, disables anonymized telemetry and ambient OTEL endpoint. Socket-watcher test exercises a fake local encoder and config rejects ambient remote backends; it does not certify all runtime egress. [Privacy](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/PRIVACY.md#L13-L17), [local embedding](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/hy_sdk_runtime.py#L53-L89), [runtime config](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/hy_runtime_config.py#L123-L138), [test scope](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/tests/test_hy_network_egress.py#L25-L89).

### H19 — Secret protection differs from content encryption

**Mechanism, bounded negative evidence.** API secrets use OS keyring; management SQLite files and sidecars get owner-only mode. Inspected content-store construction and privacy docs do not establish application-level encryption of memories/embeddings at rest. A lexical search for encryption/Fernet/SQLCipher/AES across `memhub/apps/core/src` and `memhub/packages` returned keyring/file-mode mechanisms rather than content encryption. This is **unverified encryption**, not an exhaustive proof none exists, and says nothing about OS disk encryption. [Keyring](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/secrets.py#L76-L97), [SQLite modes](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/database_access.py#L851-L869).

### H20 — Debug logging materially changes the privacy boundary

**Mechanism/contract.** Info disables pipeline/content logging, debug enables full LLM prompt/response locally. Returning to info does not remove existing debug files. Thus a sanitized diagnostic-export promise must not be generalized to every local log. [Disclosure](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/PRIVACY.md#L23-L36), [live flags](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/hy_runtime_config.py#L87-L114).

### H21 — Current MemHub raw retention is only three days

**Mechanism.** `RAW_RETENTION_DAYS=3`; pruning lists L1 raw and deletes records older than cutoff using event time or creation time. Background pruning is periodic and best effort. Derived facts persist beyond raw, so long-term recalled claims may outlive their original local evidence. [Constant](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/sdk_memory_runtime.py#L34-L36), [pruning](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/sdk_memory_runtime.py#L73-L125).

### H22 — Migration history demonstrates provenance and freshness failures can happen

**Contract and mechanism.** Current migration docs report a collection-rename failure showing **37 of 3,317 memories** and require SDK readback before cutover. Legacy evidence/governance/Matter tables are dropped; new homes start with SDK authority. Current metadata repair pools older backup evidence to restore sources/times. Existing old tests/modules are not sufficient evidence for current behavior. [Migration disclosure](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/docs/contracts/sdk-data-plane-migration-v1.md#L21-L59), [repair](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/apps/core/src/one_memory/hy_sdk_migration.py#L147-L180). This is an observed engineering failure recorded by authors, not an independent incident audit.

### H23 — Evaluation must distinguish recall, action success and writer quality

**Research.** CMB reports 216 executable tasks and 750 QA questions across nine repositories; histories are synthetic and interleaved, with 87% of decision points referring to a nonlatest revision. Code grades patches against tests; QA uses model-derived requirements. Reported TriLink Code scores are 43.1%/35.6% for Sonnet-5/Flash. Fixed runs do not establish significance; raw FullContext beats TriLink under Sonnet-5. Metadata-assisted grouping, unmatched token budgets and excluded construction costs limit transfer. The snapshot tree has the paper and SDK but no identified CMB frozen dataset/full benchmark harness; reproducibility is therefore **not established from this checkout**. [Pinned CMB, pp. 4, 6–10, 18–19](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/docs/papers/CMB_A_Coding_Memory_Benchmark_for_Long_Horizon_and_Interleaved_Coding_Agents.pdf).

### H24 — Published research gains are narrower than product-wide proof

**Research.** DCPM evaluates LongMemEval, PersonaMem and PersonaMem-v2, with larger System2 gain on implicit preference inference; the paper uses a no-think protocol and model judging for LongMemEval. It does not evaluate this October MemHub cutover. [DCPM v1, §§4–6, pp. 4–8](https://arxiv.org/pdf/2606.09483v1). The later writer report holds reader/retrieval/harness fixed, uses fixed **20% subsamples**, equal-weights six metrics/four harnesses, and reports **55.49% versus 54.62%** macro average against Opus 5. It explicitly treats 0.01–0.02 point margins as parity, not statistically resolved differences. Its CMB metric is two-repository **QA**, not the full execution benchmark. Public weights plus source do not establish release of the exact sampled IDs, prompts, banks and scoring artifacts. [Writer report v1, §8.1–8.2, p. 11](https://arxiv.org/pdf/2610.22196v1).

### H25 — Operational burden and licensing depend on chosen layer

**Mechanism/contract.** SDK Apache-2.0; its opening definition scopes the grant to publicly released code, parameters and weights. Third-party terms remain relevant. Core dependencies include Chroma, Kuzu, sklearn, OpenAI SDK, tokenization and JSON repair; optional rerank adds torch/transformers. MemHub adds Node 24/pnpm 11/Python 3.12/uv development stack, Electron, ONNX, OS keyring and a persistent system runtime. Current stated targets macOS/Linux, Windows unsupported. MCP/host bridge can be a narrow consumption boundary; embedding the SDK or deploying the full app entails materially broader dependencies. No new stack installation was attempted. [License](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/LICENSE#L1-L13), [dependencies](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/pyproject.toml#L16-L58), [platform/development](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/README.md#L21-L35), [toolchain](https://github.com/Tencent-Hunyuan/Hy-Memory/blob/1c0cbf6d05c7b47fa815b91b363d34b6a9f67d41/memhub/README.md#L64-L72).

## Candidate effect experiments (provisional; not executed or approved spend)

1. **Recall versus authority contamination (H13).** Synthetic history contains an obsolete decision, an agent report falsely claiming approval, and quoted malicious instructions. Compare baseline versus MCP recall on next-task correctness, unauthorized actions and citation accuracy. Fail if any recalled statement grants authority absent current-user authorization.
2. **Temporal contradiction and deletion (H03/H06–H10).** Write A→B→retraction with fixed event times, then malformed reconcile output, then delete head. Measure active-state correctness, duplicate/conflict visibility, old-state resurrection and recall after expiry. Include two similar subjects and mixed timezone writes. Keep raw baseline and oracle timeline.
3. **Coding transfer measured by execution (H10–H12/H23).** Use small real repo tasks, interruption and revert sequences, hide irrelevant history. Compare no memory, raw retrieval, facts/experiences, diff chains at matched token budgets and fixed model. Grade tests/patch scope and wrong-branch edits, not self-reported learning or recall score. Include absent code-object metadata and older revisions beyond renderer budget.
4. **Current cutover permission race (H16–H18).** Synthetic sources, loopback fake provider and broker; revoke source/sedimentation/host grant while request is queued, before SDK invocation, during model response and before result publication. Measure bytes sent and bytes released independently. Repeat on fresh SDK-authority home; do not rely on legacy governance tests.
5. **Provenance survival (H04/H21/H22).** Load distinct facts with known sources, update/merge, cross migration, advance beyond raw retention and query. Count recall hits with recoverable immutable evidence, accurate event/source labels and explicit unsupported claims. Inspect backup retention separately from live raw deletion.
6. **Economic value and burden (H01/H14/H25).** A bounded sandbox pilot compares existing MCP use, direct SDK and full MemHub only if authorized. Measure next-action success, prompt tokens, extraction/embedding calls, latency, resident memory/disk, retry/queue recovery, manual intervention and deletion completeness. API/model spend must be separately authorized; nothing here authorizes it.

These experiments would falsify candidate benefits if correctness/authorization regresses, exact source recovery is unavailable where required, or resource/maintenance cost outweighs measured next-action improvement.

## Important unknowns / next evidence needed

- Exact installed operator service identity/version is deliberately unknown; do not infer Tencent implementation from tool naming.
- Current SDK-authority handling of per-memory/source host exclusions and remote-send revocation needs execution against the current path. Legacy `SourceReadAccess`, QA permissions tests and DeepWiki explain a prior architecture.
- Whether public source-text expansion exists for every result after three-day raw pruning; current recall receipts have no evidence IDs.
- Whether content encryption exists beyond inspected file permissions/OS secret store; OS disk encryption and provider retention policies not inspected.
- Full CMB frozen histories, environment images, exact commit mapping to the paper, eval scripts, fixed writer-report sample IDs and judge outputs were not located in the inspected tree. A negative universal claim about public availability is not made.
- Release artifacts were not downloaded, signatures/notarization not independently verified, no tests run; source intent is not deployed assurance.

## Exact inspected-source inventory

All paths below are relative to the pinned source snapshot; reads include complete files for short files and targeted numbered excerpts/search hits for large files. Full source snapshot is available to reproduce every cited line.

```text
LICENSE
memhub/LICENSE
README.md
memhub/README.md
pyproject.toml
memhub/apps/core/pyproject.toml
memhub/PRIVACY.md
docs/usage.md
docs/hy_memory_search_skill.md
docs/pro_graph_design.md
memhub/docs/ARCHITECTURE.md
memhub/docs/contracts/sdk-data-plane-migration-v1.md
hy_memory/models/memory.py
hy_memory/coding/types.py
hy_memory/coding/fact_reconciler.py
hy_memory/coding/chain_store.py
hy_memory/agent/extractor.py
hy_memory/agent/reconciler.py
hy_memory/pipelines/writer.py
hy_memory/pipelines/_retrieval/intention.py
hy_memory/client.py
memhub/apps/core/src/one_memory/hy_runtime_config.py
memhub/apps/core/src/one_memory/hy_sdk_runtime.py
memhub/apps/core/src/one_memory/hy_sdk_migration.py
memhub/apps/core/src/one_memory/sdk_memory_runtime.py
memhub/apps/core/src/one_memory/sdk_write_processor.py
memhub/apps/core/src/one_memory/secrets.py
memhub/apps/core/src/one_memory/database_access.py
memhub/apps/core/src/one_memory/source_read_access.py
memhub/apps/core/src/one_memory/context_auto_recall.py
memhub/apps/core/src/one_memory/conversation_processing.py
memhub/apps/core/src/one_memory/memory_tasks.py
memhub/apps/core/src/one_memory/model_profiles.py
memhub/apps/core/src/one_memory/api.py
memhub/apps/core/src/one_memory/recall.py
memhub/apps/core/src/one_memory/imports/sources/codex.py
memhub/packages/host-bridge/src/mcp-session.ts
memhub/packages/host-bridge/src/recall-broker.ts
memhub/packages/host-bridge/src/host-broker-permissions.test.ts
memhub/apps/core/tests/test_hy_network_egress.py
memhub/apps/core/tests/test_hy_log_privacy.py
memhub/apps/core/tests/test_source_permission_races.py
memhub/apps/core/tests/test_memory_qa_permissions.py
memhub/apps/core/tests/test_raw_vector_scale_benchmark.py
memhub/apps/core/tests/test_context_raw_scale_benchmark.py
```

Additional bounded `rg` searches covered source names/TTL/deletion/provenance/permission/encryption and evaluation artifact names throughout the text snapshot. `bench_raw_vector_scale.py` and `bench_context_raw_scale.py` referenced by inspected tests were not present among the 68 `memhub/scripts` files in this snapshot: those tests explicitly skip when scripts are missing. These are scale probes, not reproductions of the research benchmarks.

Paper snapshots: `hy/cmb.pdf` (19 pages), `hy/dcpm.pdf` (11 pages, v1), `hy/writer.pdf` (15 pages, v1), plus text derivatives. No repository or external state was mutated.

